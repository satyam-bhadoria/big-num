import { INumeralSystem } from "./numeral-system";

export interface IDecimal {
  sys: INumeralSystem;
  sign: number;
  int: number[];
  deci: number;
}