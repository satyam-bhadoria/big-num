import { INumeralSystem } from '../interfaces';

class NumeralSystem  implements INumeralSystem {
  getBase(): number {
    return 10;
  }

  min(): string {
    return '0';
  }

  max(): string {
    return '9';
  }

  getPositiveChar(): string {
    return '+';
  }

  getNegativeChar(): string {
    return '-';
  }

  getRadixPointChar(): string {
    return '.';
  }

  toDigit(ch: string): number {
    if (ch >= '0' && ch <= '9') {
      return ch.charCodeAt(0) - 48;
    }

    throw new Error('Not valid digit: ' + ch);
  }

  toChar(digit: number): string {
    return String.fromCharCode(digit + 48);
  }
}

export const NumeralSystem10 = new NumeralSystem();
